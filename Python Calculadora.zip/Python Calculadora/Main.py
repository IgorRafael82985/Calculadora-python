import customtkinter

janela = customtkinter.CTk()
janela.title("Calculadora")
janela.geometry("800x500")
janela._set_appearance_mode("system")

titulo = customtkinter.CTkLabel(janela, text="Calculadora")
titulo.pack(pady=20)

def somar():
    try:
        num1 = float(n1.get())
        num2 = float(n2.get())
        resultado = num1 + num2
        label.configure(text=f"{num1} + {num2} = {resultado}")
    except ValueError:
        label.configure(text="Entrada inválida")

def subtrair():
    try:
        num1 = float(n1.get())
        num2 = float(n2.get())
        resultado = num1 - num2
        label.configure(text=f"{num1} - {num2} = {resultado}")
    except ValueError:
        label.configure(text="Entrada inválida")

def multiplicar():
    try:
        num1 = float(n1.get())
        num2 = float(n2.get())
        resultado = num1 * num2
        label.configure(text=f"{num1} x {num2} = {resultado}")
    except ValueError:
        label.configure(text="Entrada inválida")

def dividir():
    try:
        num1 = float(n1.get())
        num2 = float(n2.get())
        if num2 == 0:
            label.configure(text="Divisão por zero!")
        else:
            resultado = num1 / num2
            label.configure(text=f"{num1} / {num2} = {resultado}")
    except ValueError:
        label.configure(text="Entrada inválida")

# Entradas
n1 = customtkinter.CTkEntry(janela, placeholder_text="Digite o primeiro número", width=200)
n1.pack(pady=20)

n2 = customtkinter.CTkEntry(janela, placeholder_text="Digite o segundo número", width=200)
n2.pack(pady=20)

# Botões
customtkinter.CTkButton(master=janela, text="Somar", command=somar).pack(pady=10)
customtkinter.CTkButton(master=janela, text="Subtrair", command=subtrair).pack(pady=10)
customtkinter.CTkButton(master=janela, text="Multiplicar", command=multiplicar).pack(pady=10)
customtkinter.CTkButton(master=janela, text="Dividir", command=dividir).pack(pady=10)

# Resultado
label = customtkinter.CTkLabel(janela, text="=")
label.pack(pady=20)

janela.mainloop()
