from cx_Freeze import setup, executable

build_exe_options = {
    "packages": ["customkinter"],
    "include_files": ["icone.ico"]
}

executables = [
    executable.Executable("Main.py", base="Win32GUI", icon="icone.ico")
]

setup(
    name="calculadora python",
    version="1.0",
    description="Programa para realizar as quatro operações basicas",
    options={"Build_exe": build_exe_options},
    executables=executables
)
